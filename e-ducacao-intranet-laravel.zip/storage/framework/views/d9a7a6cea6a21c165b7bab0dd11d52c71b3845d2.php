<footer class="blockquote-footer" style="text-align: center;">
    <div class="copyright">
        &copy; Desenvolvido por Sarat & Vargas WebDevelopers. Todos os direitos reservados.
    </div>
</footer><?php /**PATH C:\Users\maxsa\Desktop\GitHub\e-ducacao-intranet-laravel\resources\views/components/componente_footer.blade.php ENDPATH**/ ?>