<?php $__env->startSection('body'); ?>
    <div class="card border">
        <div class="card-body">
            <h5 class="card-title">Painel de Conteúdos - Ensino Fundamental - <?php echo e($tipo); ?> - <?php echo e($bim); ?>º Bimestre</h5>
            <table class="table table-striped table-ordered table-hover" style="text-align: center;">
                <thead class="thead-dark">
                    <tr>
                        <th>Disciplinas</th>
                        <?php $__currentLoopData = $fundTurmas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($turma->serie); ?>º ANO</th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $profDiscs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profDisc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $fundDiscs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fundDisc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($fundDisc->id==$profDisc->disciplina_id): ?>
                                <tr>
                                    <td><?php echo e($fundDisc->nome); ?></td>
                                    <?php $__currentLoopData = $fundTurmas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $contFunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contFund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($contFund->disciplina->nome == $fundDisc->nome && $contFund->serie==$turma->serie): ?>
                                                <?php if($turma->serie==6 || $turma->serie==7 || $turma->serie==8): ?>
                                                    <?php if($contFund->disciplina->nome=="Biologia" || $contFund->disciplina->nome=="Física" || $contFund->disciplina->nome=="Química"): ?> <td style="color:blue; text-align: center; font-weight:bold;">Não se <br/>Aplica</td> <?php else: ?>
                                                        <?php if($contFund->arquivo==''): ?> <td style="color:red; text-align: center;"> Pendente <br/> <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#modal6<?php echo e($contFund->id); ?>"><i class="material-icons md-48">cloud_upload</i></button>  <?php else: ?> <td style="color:green; text-align: center;"><i class="material-icons md-48 green600">check_circle</i><br/> <a type="button" class="btn btn-success" href="/prof/conteudos/download/<?php echo e($contFund->id); ?>"><i class="material-icons md-48">cloud_download</i></a> <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#modal6<?php echo e($contFund->id); ?>"><i class="material-icons md-48">edit</i></button> <a type="button" class="btn btn-danger" href="/prof/conteudos/apagar/<?php echo e($contFund->id); ?>"><i class="material-icons md-48">delete</i></a> <?php endif; ?> </td>
                                                            <!-- Modal -->
                                                            <div class="modal fade" id="modal6<?php echo e($contFund->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                                <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">Anexar Conteúdo da <?php echo e($tipo); ?> - <?php echo e($contFund->disciplina->nome); ?> - <?php echo e($contFund->serie); ?>º ANO</h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <form method="POST" action="/prof/conteudos/anexar/<?php echo e($contFund->id); ?>" enctype="multipart/form-data">
                                                                            <?php echo csrf_field(); ?>
                                                                            <input type="file" id="arquivo" name="arquivo" accept=".doc,.docx,.pdf" required>
                                                                            <br/>
                                                                            <b style="font-size: 90%;">Aceito apenas extensões do Word e PDF (".doc", ".docx" e ".pdf")</b>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                    <button type="submit" class="btn btn-primary">Enviar</button>
                                                                    </div>
                                                                </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                <?php if($contFund->disciplina->nome=="Arte" || $contFund->disciplina->nome=="Ciências" || $contFund->disciplina->nome=="Educação Física"): ?> <td style="color:blue; text-align: center; font-weight:bold;">Não se <br/>Aplica</td> <?php else: ?>
                                                        <?php if($contFund->arquivo==''): ?> <td style="color:red; text-align: center;"> Pendente <br/> <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#modal6<?php echo e($contFund->id); ?>"><i class="material-icons md-48">cloud_upload</i></button>  <?php else: ?> <td style="color:green; text-align: center;"><i class="material-icons md-48 green600">check_circle</i><br/> <a type="button" class="btn btn-success" href="/prof/conteudos/download/<?php echo e($contFund->id); ?>"><i class="material-icons md-48">cloud_download</i></a> <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#modal6<?php echo e($contFund->id); ?>"><i class="material-icons md-48">edit</i></button> <a type="button" class="btn btn-danger" href="/prof/conteudos/apagar/<?php echo e($contFund->id); ?>"><i class="material-icons md-48">delete</i></a> <?php endif; ?> </td>
                                                            <!-- Modal -->
                                                            <div class="modal fade" id="modal6<?php echo e($contFund->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                                <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">Anexar Conteúdo da <?php echo e($tipo); ?> - <?php echo e($contFund->disciplina->nome); ?> - <?php echo e($contFund->serie); ?>º ANO</h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <form method="POST" action="/prof/conteudos/anexar/<?php echo e($contFund->id); ?>" enctype="multipart/form-data">
                                                                            <?php echo csrf_field(); ?>   
                                                                            <input type="file" id="arquivo" name="arquivo" accept=".doc,.docx,.pdf" required>
                                                                            <br/>
                                                                            <b style="font-size: 90%;">Aceito apenas extensões do Word e PDF (".doc", ".docx" e ".pdf")</b>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                    <button type="submit" class="btn btn-primary">Enviar</button>
                                                                    </div>
                                                                </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-body">
            <h5 class="card-title">Painel de Conteúdos - Ensino Médio - <?php echo e($tipo); ?> - <?php echo e($bim); ?>º Bimestre</h5>
            <table class="table table-striped table-ordered table-hover" style="text-align: center;">
                <thead class="thead-dark">
                    <tr>
                        <th>Disciplinas</th>
                        <?php $__currentLoopData = $medioTurmas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($turma->serie); ?>º ANO</th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $profDiscs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profDisc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $medioDiscs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medioDisc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($medioDisc->id==$profDisc->disciplina_id): ?>
                                <tr>
                                    <td><?php echo e($medioDisc->nome); ?></td>
                                    <?php $__currentLoopData = $medioTurmas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $contMedios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contMedio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($contMedio->disciplina->nome == $medioDisc->nome && $contMedio->serie==$turma->serie): ?>
                                                <?php if($turma->serie==3): ?>
                                                    <?php if($contMedio->disciplina->nome=="Química I"): ?> <td style="color:blue; text-align: center; font-weight:bold;">Não se <br/>Aplica</td> <?php else: ?>
                                                        <?php if($contMedio->arquivo==''): ?> <td style="color:red; text-align: center;"> Pendente <br/> <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#modal6<?php echo e($contMedio->id); ?>"><i class="material-icons md-48">cloud_upload</i></button>  <?php else: ?> <td style="color:green; text-align: center;"><i class="material-icons md-48 green600">check_circle</i><br/> <a type="button" class="btn btn-success" href="/prof/conteudos/download/<?php echo e($contMedio->id); ?>"><i class="material-icons md-48">cloud_download</i></a> <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#modal6<?php echo e($contMedio->id); ?>"><i class="material-icons md-48">edit</i></button> <a type="button" class="btn btn-danger" href="/prof/conteudos/apagar/<?php echo e($contMedio->id); ?>"><i class="material-icons md-48">delete</i></a> <?php endif; ?> </td>
                                                            <!-- Modal -->
                                                            <div class="modal fade" id="modal6<?php echo e($contMedio->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                                <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">Anexar Conteúdo da <?php echo e($tipo); ?> - <?php echo e($contMedio->disciplina->nome); ?> - <?php echo e($contMedio->serie); ?>º ANO</h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <form method="POST" action="/prof/conteudos/anexar/<?php echo e($contMedio->id); ?>" enctype="multipart/form-data">
                                                                            <?php echo csrf_field(); ?>
                                                                            <input type="file" id="arquivo" name="arquivo" accept=".doc,.docx,.pdf" required>
                                                                            <br/>
                                                                            <b style="font-size: 90%;">Aceito apenas extensões do Word e PDF (".doc", ".docx" e ".pdf")</b>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                    <button type="submit" class="btn btn-primary">Enviar</button>
                                                                    </div>
                                                                </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                        <?php if($contMedio->arquivo==''): ?> <td style="color:red; text-align: center;"> Pendente <br/> <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#modal6<?php echo e($contMedio->id); ?>"><i class="material-icons md-48">cloud_upload</i></button>  <?php else: ?> <td style="color:green; text-align: center;"><i class="material-icons md-48 green600">check_circle</i><br/> <a type="button" class="btn btn-success" href="/prof/conteudos/download/<?php echo e($contMedio->id); ?>"><i class="material-icons md-48">cloud_download</i></a> <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#modal6<?php echo e($contMedio->id); ?>"><i class="material-icons md-48">edit</i></button> <a type="button" class="btn btn-danger" href="/prof/conteudos/apagar/<?php echo e($contMedio->id); ?>"><i class="material-icons md-48">delete</i></a> <?php endif; ?> </td>
                                                            <!-- Modal -->
                                                            <div class="modal fade" id="modal6<?php echo e($contMedio->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                                <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">Anexar Conteúdo da <?php echo e($tipo); ?> - <?php echo e($contMedio->disciplina->nome); ?> - <?php echo e($contMedio->serie); ?>º ANO</h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <form method="POST" action="/prof/conteudos/anexar/<?php echo e($contMedio->id); ?>" enctype="multipart/form-data">
                                                                            <?php echo csrf_field(); ?>
                                                                            <input type="file" id="arquivo" name="arquivo" accept=".doc,.docx,.pdf" required>
                                                                            <br/>
                                                                            <b style="font-size: 90%;">Aceito apenas extensões do Word e PDF (".doc", ".docx" e ".pdf")</b>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                    <button type="submit" class="btn btn-primary">Enviar</button>
                                                                    </div>
                                                                </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <br>
    <a href="/prof/conteudos/<?php echo e($ano); ?>" class="btn btn-success" data-toggle="tooltip" data-placement="bottom" title="Voltar"><i class="material-icons white">reply</i></a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ["current"=>"conteudos"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxsa\Desktop\GitHub\e-ducacao-intranet-laravel\resources\views/profs/conteudos.blade.php ENDPATH**/ ?>