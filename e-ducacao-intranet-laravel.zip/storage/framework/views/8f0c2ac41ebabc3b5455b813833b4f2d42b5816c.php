<?php $__env->startSection('body'); ?>
    <div class="card border">
        <?php if($ensino=="fund"): ?>
        <div class="card-body">
            <h5 class="card-title">Painel de Conteúdos - Ensino Fundamental - <?php echo e($tipo); ?> - <?php echo e($bim); ?>º Bimestre</h5>
            <table class="table table-striped table-ordered table-hover" style="text-align: center;">
                <thead class="thead-dark">
                    <tr>
                        <th>Disciplinas</th>
                        <th><?php echo e($serie); ?>º ANO</th>
                    </tr>
                </thead>
                <tbody>
                        <?php $__currentLoopData = $fundDiscs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fundDisc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($fundDisc->nome); ?></td>
                                        <?php $__currentLoopData = $contFunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contFund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($contFund->disciplina->nome == $fundDisc->nome && $contFund->serie==$serie): ?>
                                                <?php if($contFund->arquivo==''): ?> <td style="color:red; text-align: center;"> Pendente <br/> Solicite ao Professor(a) <?php else: ?> <td style="color:green; text-align: center;"><i class="material-icons md-48 green600">check_circle</i><br/> <a type="button" class="btn btn-success" href="/aluno/conteudos/download/<?php echo e($contFund->id); ?>"><i class="material-icons md-48">cloud_download</i></a> <?php endif; ?> </td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
        <?php if($ensino=="medio"): ?>
        <div class="card-body">
            <h5 class="card-title">Painel de Conteúdos - Ensino Médio - <?php echo e($tipo); ?> - <?php echo e($bim); ?>º Bimestre</h5>
            <table class="table table-striped table-ordered table-hover" style="text-align: center;">
                <thead class="thead-dark">
                    <tr>
                        <th>Disciplinas</th>
                        <th><?php echo e($serie); ?>º ANO</th>
                    </tr>
                </thead>
                <tbody>
                        <?php $__currentLoopData = $medioDiscs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medioDisc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($medioDisc->nome); ?></td>

                                        <?php $__currentLoopData = $contMedios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contMedio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($contMedio->disciplina->nome == $medioDisc->nome && $contMedio->serie==$serie): ?>
                                                <?php if($contMedio->arquivo==''): ?> <td style="color:red; text-align: center;"> Pendente <br/> Solicite ao Professor(a) <?php else: ?> <td style="color:green; text-align: center;"><i class="material-icons md-48 green600">check_circle</i><br/> <a type="button" class="btn btn-success" href="/aluno/conteudos/download/<?php echo e($contMedio->id); ?>"><i class="material-icons md-48">cloud_download</i></a> <?php endif; ?> </td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
    <br>
    <a href="/aluno/conteudos/<?php echo e($ano); ?>" class="btn btn-success" data-toggle="tooltip" data-placement="bottom" title="Voltar"><i class="material-icons white">reply</i></a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ["current"=>"conteudo"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxsa\Desktop\GitHub\e-ducacao-intranet-laravel\resources\views/alunos/conteudos.blade.php ENDPATH**/ ?>