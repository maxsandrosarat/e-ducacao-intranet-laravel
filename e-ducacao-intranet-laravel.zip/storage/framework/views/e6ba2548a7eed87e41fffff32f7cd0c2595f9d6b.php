<?php $__env->startSection('body'); ?>
<div class="jumbotron bg-light border border-secondary">
    <div class="row">
        <div class="card-deck">
            <div class="card border border-primary">
                <div class="card-body">
                    <h5>Atividades</h5>
                    <p class="card-text">
                        Baixar os arquivos de Atividades e enviar Retorno
                    </p>
                    <a href="/aluno/atividade/disciplinas" class="btn btn-primary">Atividades</a>
                </div>
            </div>
            <div class="card border border-primary">
                <div class="card-body">
                    <h5>Conteúdos</h5>
                    <p class="card-text">
                        Baixar os Conteúdos
                    </p>
                    <a href="/aluno/conteudos/<?php echo e(date("Y")); ?>" class="btn btn-primary">Conteúdos</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ["current"=>"home"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxsa\Desktop\GitHub\e-ducacao-intranet-laravel\resources\views/alunos/home_aluno.blade.php ENDPATH**/ ?>