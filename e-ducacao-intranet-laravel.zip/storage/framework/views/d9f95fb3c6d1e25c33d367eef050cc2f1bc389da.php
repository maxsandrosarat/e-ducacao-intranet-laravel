<?php $__env->startSection('body'); ?>
    <div class="card border">
        <div class="card-body">
            <h5 class="card-title">Painel de Atividades</h5>
            <?php if(count($atividades)==0): ?>
                <div class="alert alert-danger" role="alert">
                    Sem atividades para exibir!
                </div>
            <?php else: ?>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                        <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>
            <h5>Exibindo <?php echo e($atividades->count()); ?> de <?php echo e($atividades->total()); ?> de Atividades (<?php echo e($atividades->firstItem()); ?> a <?php echo e($atividades->lastItem()); ?>)</h5>
            <table class="table table-striped table-ordered table-hover" style="text-align: center;">
                <thead class="thead-dark">
                    <tr>
                        <th>Disciplina</th>
                        <th>Atividade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $atividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atividade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($atividade->disciplina->nome); ?></td>
                        <td style="text-align: center;">
                            <div class="card">
                                <div class="card-header">
                                    <?php echo e($atividade->descricao); ?>

                                </div>
                                <div class="card-body">
                                  <p class="card-text">Visualizações: <?php echo e($atividade->visualizacoes); ?> | Data Criação: <?php echo e(date("d/m/Y", strtotime($atividade->data_criacao))); ?> <?php if($atividade->data_publicacao!=""): ?> | Data Publicação: <?php echo e(date("d/m/Y", strtotime($atividade->data_publicacao))); ?> <?php endif; ?> <?php if($atividade->data_expiracao!=""): ?> | <b style="color:red;">Data Expiração: <?php echo e(date("d/m/Y", strtotime($atividade->data_expiracao))); ?></b> <?php endif; ?></p>
                                  <?php if($atividade->link!=""): ?><a href="<?php echo e($atividade->link); ?>" target="_blank" class="btn btn-primary">Link Vídeo-Aula</a><?php endif; ?>
                                  <a type="button" class="btn btn-success" href="/aluno/atividade/download/<?php echo e($atividade->id); ?>"><i class="material-icons md-48">cloud_download</i></a>
                                  <?php if($atividade->retorno=="sim"): ?>
                                    <?php if(count($retornos)==0): ?>
                                        <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModalCreate<?php echo e($atividade->id); ?>">
                                            Enviar Retorno
                                        </button>
                                    <?php else: ?>
                                        <?php $contador=0; ?>
                                        <?php $__currentLoopData = $retornos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retorno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($retorno->atividade_id==$atividade->id): ?>
                                                <?php $contador++; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($contador>0): ?>
                                            <i class="material-icons md-48 green600">check_circle</i>
                                            <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModalEdit<?php echo e($atividade->id); ?>">
                                                <i class="material-icons md-48">edit</i>
                                            </button>
                                        <?php else: ?>
                                            <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModalCreate<?php echo e($atividade->id); ?>">
                                                Enviar Retorno
                                            </button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <!-- Modal -->
                                <div class="modal fade" id="exampleModalCreate<?php echo e($atividade->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Retorno da Atividade - <?php echo e($atividade->descricao); ?></h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form method="POST" action="/aluno/atividade/retorno/<?php echo e($atividade->id); ?>" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <label for="comentario" class="col-md-4 col-form-label text-md-right">Comentário</label>
                                            <textarea name="comentario" id="comentario" rows="10" cols="40" maxlength="500"></textarea> 
                                            <br/>
                                            <input type="file" id="arquivo" name="arquivo" accept=".doc,.docx,.pdf" required>
                                            <br/>
                                            <b style="font-size: 80%;">Aceito apenas extensões do Word e PDF (".doc", ".docx" e ".pdf")</b>
                                        </div>
                                        <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                        <button type="submit" class="btn btn-primary">Enviar</button>
                                        </div>
                                    </form>    
                                    </div>
                                    </div>
                                </div>
                                </div>
                                </div>
                            </div>
                            <!-- Modal -->
                                <div class="modal fade" id="exampleModalEdit<?php echo e($atividade->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Editar Retorno da Atividade - <?php echo e($atividade->descricao); ?></h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <?php $__currentLoopData = $retornos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retorno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($retorno->atividade_id==$atividade->id): ?>
                                    <div class="modal-body">
                                        <form method="POST" action="/aluno/atividade/retorno/editar/<?php echo e($retorno->id); ?>" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <label for="comentario" class="col-md-4 col-form-label text-md-right">Comentário</label>
                                            <textarea name="comentario" id="comentario" rows="10" cols="40" maxlength="500"><?php echo e($retorno->comentario); ?></textarea>
                                            <br/>
                                            <input type="file" id="arquivo" name="arquivo" accept=".doc,.docx,.pdf" required>
                                            <br/>
                                            <b style="font-size: 80%;">Aceito apenas extensões do Word e PDF (".doc", ".docx" e ".pdf")</b>
                                    </div>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                    <button type="submit" class="btn btn-primary">Enviar</button>
                                    </div>
                                    </form>
                                    </div>
                                    </div>
                                </div>
                                </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="card-footer">
                <?php echo e($atividades->links()); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
    <br/>
    <a href="/aluno/atividade/disciplinas" class="btn btn-success" data-toggle="tooltip" data-placement="bottom" title="Voltar"><i class="material-icons white">reply</i></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ["current"=>"atividade"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxsa\Desktop\GitHub\e-ducacao-intranet-laravel\resources\views/alunos/atividade_aluno.blade.php ENDPATH**/ ?>