<footer class="blockquote-footer" style="text-align: center;">
    <div class="copyright">
        &copy; Desenvolvido por Sarat & Vargas WebDevelopers. Todos os direitos reservados.
    </div>
</footer>