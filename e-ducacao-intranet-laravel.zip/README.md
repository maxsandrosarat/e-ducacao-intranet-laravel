# e-ducacao-intranet-laravel
 Sistema para Auxilio Pedagógico
