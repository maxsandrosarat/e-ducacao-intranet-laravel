<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ListaCompra extends Model
{
    
}
